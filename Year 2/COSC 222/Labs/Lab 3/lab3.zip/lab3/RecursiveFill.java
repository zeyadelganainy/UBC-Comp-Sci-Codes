package lab3;

import java.awt.Color;

public class RecursiveFill {
 public static final int WIDTH = 1000, HEIGHT = 600;
 public static final int MIN_SIZE = 20;
 public static final int MIN_SIZE_BONUS = 10;
 
 public static void main(String[] args){
    StdDraw.setCanvasSize(WIDTH,HEIGHT);
    StdDraw.show(0);
    recursiveRectangleFill(0,1,0,1);
	//recursiveBonus(0.5,0,0.1); //comment-out whichever line you're not working on
    StdDraw.show(0);
 }

 public static void recursiveRectangleFill(double minX, double maxX, double minY, double maxY){

      /* YOUR CODE HERE */

}



 public static void recursiveBonus(double centerX, double centerY, double radius){

  /* YOUR CODE HERE */

 }
 

}
