import java.util.LinkedList;

public class Graph {

	// Represents the number of vertices (nodes) in the graph
	private int numVertices;  
	
	// Stores the adjacency matrix
	private int[][] adjMatrix;
	
	// Stores the adjacency lists (note it is an array of LinkedLists)
	private LinkedList<Integer>[] adjListArray;
	
	public Graph(int[][] adjMatrix) {

		/* YOUR CODE HERE */
		
	}
	
	private void generateAdjList() {

		/* YOUR CODE HERE */
		
	}
	
	// A method to print the adjacency matrix
	public void printMatrix() {

		/* YOUR CODE HERE */
		
	}
	
	// A method to print the adjacency list 
	public void printList() {

		/* YOUR CODE HERE */
		
	}
}
